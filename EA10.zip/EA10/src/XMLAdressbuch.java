
import java.io.File;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/**
 * Klasse zum strukturieren einer XML-Datei in einen DOM-Baum.
 * @author Gruppe n
 *
 */

public class XMLAdressbuch {
	/**
	 * NodeList und Arraylist m�ssen Klassen�berfreifend sein, damit jede
	 * Methode auf diese Listen zugreifen kann.
	 */
	NodeList nList;
	ArrayList<Kontakt> kontaktArray = new ArrayList<Kontakt>();
	/**
	 * Methode zum Strukturieren einer XML Datein in einen DOM-Baum
	 * @param dateiname Name der XML-Datei, die in den DOM-Parser eigegeben werden soll
	 */
	public void liesAdressenAusXML(String dateiname) {
		try {
			DocumentBuilderFactory dbFact = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuild = dbFact.newDocumentBuilder();
			Document doc = dBuild.parse(new File(dateiname));
			
			nList = doc.getElementsByTagName("Kontakt");
		}
		catch (Exception e) {
			
		}
	}
	/**
	 * Uebergiebt die Vor- und Nachnamen des DOM-Baums
	 * in eine Klassenuebergreifende Arraylist und giebt die 
	 * Namen Strukturiert aus
	 * @return nameArray, Arraylist der Vor- und Nachnamen aller im DOM-Baum
	 * erhaltnen Kontakte.
	 */
public ArrayList<String> getAlleNamen(){
		ArrayList<String> nameArray= new ArrayList<String>();
		
		for(int i=0; i<nList.getLength(); i++) {
			Node nNode=nList.item(i);
			 
			if(nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				nameArray.add(eElement.getElementsByTagName("Vorname").item(0).getTextContent() + " " +
				eElement.getElementsByTagName("Nachname").item(0).getTextContent());
				
				int count = i+1;
				System.out.println("["+count+"]"+nameArray.get(i));
			}	
		}
		return nameArray;
	}
	/**
	 * Entnimmt alle Kontaktdaten einer vorher ausgewaelten Person aus dem DOM-Baum
	 * und speichert diese in eine Klassenuebergreifenden ArrayList vom Typ Kontakt
	 * @param vorname Vorname der zu speichernden Person
	 * @param nachname Nachname der zu speichernden Person
	 * @return kontaktArray ArrayList mit allen gespeicherten Personen
	 */
public ArrayList<Kontakt> getAdressenZu(String vorname, String nachname){
	for(int i=0; i<nList.getLength(); i++) {
		Node nNode=nList.item(i);
		
		
		if(nNode.getNodeType() == Node.ELEMENT_NODE) {
			Element eElement = (Element) nNode;
			
			if(eElement.getElementsByTagName("Vorname").item(0).getTextContent().equals(vorname) && 
					eElement.getElementsByTagName("Nachname").item(0).getTextContent().equals(nachname)) {
				
				Kontakt kon = new Kontakt(null,
						Kontakt.KontaktTyp.valueOf(eElement.getAttribute("typ")), 
						eElement.getElementsByTagName("Nachname").item(0).getTextContent(),
						eElement.getElementsByTagName("Vorname").item(0).getTextContent(), 
						eElement.getElementsByTagName("Strasse").item(0).getTextContent(), 
						eElement.getElementsByTagName("PLZ").item(0).getTextContent(), 
						eElement.getElementsByTagName("Ort").item(0).getTextContent(),
						eElement.getElementsByTagName("Land").item(0).getTextContent());
				kontaktArray.add(kon);	
			}
		}
	}
	return kontaktArray;
}	
}

