import java.util.Scanner;
/**
 * Main Klasse zur Ausf�hrung der XMLAdressbuch-Klasse
 * @author Gruppe n
 *
 */
public class Main {
	/**
	 * Main Methode, liest zu erst die XML-Datei in einen DOM-Baum ein
	 * gibt dann die Namen aller Kontakte der XML-Datei wieder
	 * und fordert dann auf eine der Personen im ArrayList zu speichern
	 * alle gespeicherten Kontakte anzuzeigen oder das Programm zu beenden.
	 * @param args
	 * @throws Exception
	 */
	
public static void main(String[] args)throws Exception {
		String dateiname = "Adressen.xml";
		XMLAdressbuch x = new XMLAdressbuch();
		x.liesAdressenAusXML(dateiname);
		boolean loop = true;
do {
	
		x.getAlleNamen();
		System.out.println("[6]Kontakliste anzeigen.");
		System.out.println("[0]Programm beenden");
		System.out.println("\n ------------------------------------ \n");
		System.out.println("Geben Sie die Nummer der entsprechenden person ein,"
				+ " die Sie zu Ihrer Kontaktliste hinzug�gen wollen.");
		Scanner sc= new Scanner(System.in);
		int eingabe = sc.nextInt();
		
		if(eingabe == 1) {
			x.getAdressenZu("Max", "Mustermann");
		}
		if(eingabe == 2) {
			x.getAdressenZu("Sandra", "Tester");
		}
		if(eingabe == 3) {
			x.getAdressenZu("Karl", "Leister");
		}
		if(eingabe == 4) {
			x.getAdressenZu("Bernd", "Business");
		}
		if(eingabe == 5) {
			x.getAdressenZu("Moritz", "Makler");
		}
		if(eingabe == 6) {
			System.out.print(x.kontaktArray);
		}
		if(eingabe == 0) {
			loop=false;
		}
		sc.close();
		}
while(loop==true);
	}

	
	

}

